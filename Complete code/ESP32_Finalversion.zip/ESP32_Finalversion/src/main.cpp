#include <Arduino.h>
#include <WiFi.h>
#include <httpUpdate.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Update.h>

// AI边缘计算模块
#include "sensor_handler.h"
#include "tf_lite_handler.h"
#include "can_handler.h"
#include "anomaly_model_data.h"

#define Version 7

// ===== 系统配置 =====
// OTA版本检查
unsigned long lastCheckTime = 0;
const unsigned long OTA_CHECK_INTERVAL = 30000; // OTA检查间隔30秒

// AI推理定时
unsigned long lastInferenceTime = 0;
const unsigned long AI_INFERENCE_INTERVAL = 500; // AI推理间隔500ms

// 系统状态
uint16_t total_inference_count = 0;
uint16_t anomaly_count = 0;

#define LED 1

#ifdef LED
#define led_pin 2
#define LED_INIT                   \
  do                               \
  {                                \
    Serial.println("LED灯初始化"); \
    pinMode(led_pin, OUTPUT);      \
  } while (0)
#define LED_ON                   \
  do                             \
  {                              \
    Serial.println("LED on");    \
    digitalWrite(led_pin, HIGH); \
  } while (0)
#define LED_OFF                 \
  do                            \
  {                             \
    Serial.println("LED off");  \
    digitalWrite(led_pin, LOW); \
  } while (0)
#endif

/******需要修改的地方****************/

#define wifi_name "Mate 60" // WIFI名称，区分大小写，不要写错
#define wifi_password "12345678" // WIFI密码
// 固件链接，在巴法云控制台复制、粘贴到这里即可
String upUrl = "http://bin.bemfa.com/b/3BcYTk0N2NiYTg1NmQyNDBmM2I0ZjFmZDg4MmExZjhmMDI=esp32s3.bin";

// 巴法云OTA配置
#define BEMFA_PRODUCT_KEY "your_product_key"
#define BEMFA_DEVICE_NAME "esp32s3"
#define BEMFA_DEVICE_SECRET "your_secret"

/**********************************/

// 全局对象
SensorHandler sensorHandler;
TFLiteAnomalyDetector anomalyDetector;
CANHandler canHandler;

// 函数声明
void updateBin();
int getBemfaLatestVersion();
void initializeAISystems();
void runAIInference();
void handleAnomalyDetection();

/**
 * 主函数
 */
void setup()
{
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n\n========== ESP32 AI异常检测系统启动 ==========");
  Serial.print("固件版本: ");
  Serial.println(Version);
  
  LED_INIT;
  
  // 连接WiFi
  Serial.println("\n[WiFi] 正在连接...");
  WiFi.begin(wifi_name, wifi_password);
  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 20)
  {
    delay(500);
    Serial.print(".");
    LED_ON;
    delay(100);
    LED_OFF;
    retry++;
  }
  
  if (WiFi.status() == WL_CONNECTED)
  {
    Serial.println("\n[WiFi] 连接成功");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
  }
  else
  {
    Serial.println("\n[WiFi] 连接失败，继续运行...");
  }
  
  // 初始化AI系统
  initializeAISystems();
  
  Serial.println("\n========== 系统初始化完成 ==========\n");
}

/**
 * 循环函数
 */
void loop()
{
  // OTA版本检查 (每30秒一次)
  if (WiFi.status() == WL_CONNECTED && millis() - lastCheckTime >= OTA_CHECK_INTERVAL)
  {
    lastCheckTime = millis();
    Serial.println("\n[OTA] 开始版本检查...");
    
    int latestVersion = getBemfaLatestVersion();
    if (latestVersion > Version)
    {
      Serial.println("[OTA] 发现新版本：" + String(latestVersion) + "（本地：" + String(Version) + "）");
      Serial.println("[OTA] 3秒后开始升级...");
      delay(3000);
      updateBin();
    }
    else if (latestVersion == Version)
    {
      Serial.println("[OTA] 当前已是最新版本");
    }
  }
  
  // AI推理循环 (每500ms一次)
  if (millis() - lastInferenceTime >= AI_INFERENCE_INTERVAL)
  {
    lastInferenceTime = millis();
    runAIInference();
  }
  
  // 非阻塞延迟
  delay(10);
}

// ========== 获取巴法云最新版本号 ==========
int getBemfaLatestVersion()
{
  const String bemfaCheckUrl = "https://cloud.bemfa.com/api/ota/check";
  HTTPClient http;
  int latestVersion = -1;

  // 构造POST请求参数
  String postData = "{\"topic\":\"ota/" + String(BEMFA_PRODUCT_KEY) + "/" + BEMFA_DEVICE_NAME + "\","
                    "\"token\":\"" + BEMFA_DEVICE_SECRET + "\","
                    "\"version\":\"" + String(Version) + "\"}";

  http.begin(bemfaCheckUrl);
  http.addHeader("Content-Type", "application/json");

  int httpCode = http.POST(postData);
  if (httpCode == HTTP_CODE_OK)
  {
    String response = http.getString();
    Serial.println("[OTA] 响应: " + response);

    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, response);
    if (!error)
    {
      int code = doc["code"];
      if (code == 0)
      {
        bool hasNew = doc["data"]["has_new"];
        if (hasNew)
        {
          String versionStr = doc["data"]["version"];
          versionStr.replace("v", "");
          latestVersion = versionStr.toInt();
        }
        else
        {
          latestVersion = Version;
        }
      }
    }
    else
    {
      Serial.println("[OTA] JSON解析失败");
    }
  }
  else
  {
    Serial.println("[OTA] 请求失败，HTTP码：" + String(httpCode));
  }

  http.end();
  return latestVersion;
}

// ========== 升级回调函数 ==========
void update_started()
{
  Serial.println("[OTA] 升级进程已启动");
  LED_ON;
}

void update_finished()
{
  Serial.println("[OTA] 升级进程已完成");
  LED_OFF;
}

void update_progress(int cur, int total)
{
  Serial.printf("[OTA] 进度: %d / %d bytes\n", cur, total);
}

void update_error(int err)
{
  Serial.printf("[OTA] 错误代码: %d\n", err);
  LED_OFF;
}

/**
 * 固件升级函数
 */
void updateBin()
{
  Serial.println("[OTA] 开始升级");
  WiFiClient UpdateClient;

  httpUpdate.onStart(update_started);
  httpUpdate.onEnd(update_finished);
  httpUpdate.onProgress(update_progress);
  httpUpdate.onError(update_error);

  t_httpUpdate_return ret = httpUpdate.update(UpdateClient, upUrl);
  switch (ret)
  {
  case HTTP_UPDATE_FAILED:
    Serial.println("[OTA] 升级失败");
    break;
  case HTTP_UPDATE_NO_UPDATES:
    Serial.println("[OTA] 无需更新");
    break;
  case HTTP_UPDATE_OK:
    Serial.println("[OTA] 升级成功");
    break;
  }
}

// ========== 初始化AI系统 ==========
void initializeAISystems()
{
  Serial.println("\n[系统] 初始化AI边缘计算模块...");
  
  // 初始化传感器
  Serial.println("[系统] 初始化传感器...");
  if (!sensorHandler.init())
  {
    Serial.println("[系统] ⚠️ 传感器初始化出现问题，但继续运行");
  }
  
  // 初始化TFLite模型
  Serial.println("[系统] 初始化TensorFlow Lite模型...");
  if (!anomalyDetector.init())
  {
    Serial.println("[系统] ❌ 模型初始化失败");
    LED_ON;
    return;
  }
  
  // 初始化CAN
  Serial.println("[系统] 初始化CAN总线...");
  if (!canHandler.init())
  {
    Serial.println("[系统] ❌ CAN初始化失败");
    return;
  }
  
  Serial.println("[系统] ✓ AI系统初始化完成");
}

// ========== AI推理主函数 ==========
void runAIInference()
{
  if (!anomalyDetector.isInitialized() || !canHandler.isInitialized())
  {
    return;
  }
  
  // 读取传感器数据
  SensorData_t sensor_data;
  bool sensor_ok = sensorHandler.readAllSensors(sensor_data);
  
  // 打印传感器数据（调试用）
  sensorHandler.printSensorData(sensor_data);
  
  // 规范化数据用于推理
  float input_data[6];
  sensorHandler.normalizeSensorData(sensor_data, input_data, 6);
  
  // 运行推理
  unsigned long inference_start = millis();
  float safety_score = anomalyDetector.runInference(input_data, 6);
  unsigned long inference_time = millis() - inference_start;
  
  if (safety_score < 0)
  {
    Serial.println("[AI] 推理失败");
    canHandler.sendError(1, "Inference Failed");
    return;
  }
  
  // 累计计数
  total_inference_count++;
  
  // 判断是否异常（安全系数低于阈值）
  const float ANOMALY_THRESHOLD = 0.5f;  // 可调整
  if (safety_score < ANOMALY_THRESHOLD)
  {
    anomaly_count++;
    Serial.print("[AI] ⚠️ 检测到异常！安全系数: ");
    Serial.println(safety_score);
    LED_ON;
    handleAnomalyDetection();
  }
  else
  {
    Serial.print("[AI] ✓ 正常，安全系数: ");
    Serial.println(safety_score);
    LED_OFF;
  }
  
  // 通过CAN发送数据
  // 1. 发送安全系数
  canHandler.sendSafetyScore(safety_score, sensor_data.timestamp);
  
  // 2. 发送传感器原始数据
  uint8_t sensor_status = sensor_ok ? 0x01 : 0x00;
  canHandler.sendSensorData(
    sensor_data.accel_x, sensor_data.accel_y, sensor_data.accel_z,
    sensor_data.temperature, sensor_data.humidity, sensor_data.mq9_ppm,
    sensor_status
  );
  
  // 3. 发送模型状态（每10次推理发送一次）
  if (total_inference_count % 10 == 0)
  {
    canHandler.sendModelStatus(
      1,                          // 模型状态: 1=正常
      (uint8_t)inference_time,    // 推理时间
      AI_INFERENCE_INTERVAL,      // 处理周期
      anomaly_count,              // 异常计数
      total_inference_count       // 总计数
    );
  }
}

// ========== 异常处理回调 ==========
void handleAnomalyDetection()
{
  // 这里可以添加异常处理逻辑：
  // - 触发警报
  // - 记录日志
  // - 启动应急协议
  
  Serial.println("[异常处理] 已触发异常检测回调");
  
  // 可选：发送警告消息到CAN
  canHandler.sendError(2, "Anomaly Detected");
}
