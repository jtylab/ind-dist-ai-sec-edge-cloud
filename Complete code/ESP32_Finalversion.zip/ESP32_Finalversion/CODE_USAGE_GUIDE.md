# ESP32-S3 AI异常检测系统 - 代码详细指南

## 系统整体架构框架

```
┌─────────────────────────────────────────────────────────────────┐
│                    ESP32-S3 主控芯片                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 1️⃣  传感器层 (SensorHandler)                            │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ • MPU6050(I2C)     → 3轴加速度数据                      │  │
│  │ • DHT11(GPIO4)     → 温度/湿度数据                      │  │
│  │ • MQ-9(ADC35)      → 气体浓度(ppm)                      │  │
│  │ ┌────────────────────────────────────────────────────┐  │  │
│  │ │ SensorData_t {                                     │  │  │
│  │ │   float accel_x, accel_y, accel_z                 │  │  │
│  │ │   float temperature, humidity, mq9_ppm            │  │  │
│  │ │   uint32_t timestamp                              │  │  │
│  │ │ }                                                  │  │  │
│  │ └────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                           ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 2️⃣  规范化层 (Normalization)                           │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ normalizeSensorData()                                   │  │
│  │ • AccelX/Y/Z:    -8~8 m/s² → -1~1                      │  │
│  │ • Temperature:   0~50°C    → -1~1                      │  │
│  │ • Humidity:      0~100%    → -1~1                      │  │
│  │ • MQ9:           0~500ppm  → 0~1                       │  │
│  │ ┌────────────────────────────────────────────────────┐  │  │
│  │ │ float input_data[6] = {                            │  │  │
│  │ │   norm_accel_x, norm_accel_y, norm_accel_z,       │  │  │
│  │ │   norm_temp, norm_humidity, norm_mq9_ppm          │  │  │
│  │ │ }                                                  │  │  │
│  │ └────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                           ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 3️⃣  AI推理层 (TFLiteAnomalyDetector)                   │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ runInference(float *input_data, int input_size)        │  │
│  │                                                         │  │
│  │ 当前: 占位符模式 (模拟异常检测)                         │  │
│  │ • 基于加速度幅值判断                                   │  │
│  │ • 基于温度/湿度极值判断                                │  │
│  │ • 返回安全系数 (0.0~1.0)                               │  │
│  │                                                         │  │
│  │ 未来: 集成真实TFLite模型                                │  │
│  │ • 加载 anomaly_model_data.h                            │  │
│  │ • 执行神经网络推理                                     │  │
│  │ • 返回异常概率                                         │  │
│  └──────────────────────────────────────────────────────────┘  │
│                           ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 4️⃣  决策层 (Anomaly Detection Logic)                  │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │                                                         │  │
│  │ if (safety_score < ANOMALY_THRESHOLD=0.5)             │  │
│  │   {                                                    │  │
│  │     // 异常!                                           │  │
│  │     anomaly_count++                                    │  │
│  │     LED_ON                                             │  │
│  │     handleAnomalyDetection()                           │  │
│  │     sendError(2, "Anomaly Detected")                   │  │
│  │   }                                                    │  │
│  │ else                                                   │  │
│  │   {                                                    │  │
│  │     // 正常                                            │  │
│  │     LED_OFF                                            │  │
│  │   }                                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                           ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 5️⃣  通信层 (CANHandler - TWAI驱动)                    │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ GPIO8(TX) ─→ TJA1050 ─→ CAN CANH                       │  │
│  │ GPIO9(RX) ←─ TJA1050 ←─ CAN CANL                       │  │
│  │                                                         │  │
│  │ 发送3个CAN消息:                                         │  │
│  │ ┌─────────────────────────────────────────────────┐   │  │
│  │ │ MSG1: 安全系数 (ID=0x100)                       │   │  │
│  │ │ Byte0-3: float safety_score                     │   │  │
│  │ │ Byte4-7: uint32_t timestamp                     │   │  │
│  │ └─────────────────────────────────────────────────┘   │  │
│  │ ┌─────────────────────────────────────────────────┐   │  │
│  │ │ MSG2: 传感器数据 (ID=0x101)                     │   │  │
│  │ │ B0: int8_t accel_x   (-128~127)                │   │  │
│  │ │ B1: int8_t accel_y                              │   │  │
│  │ │ B2: int8_t accel_z                              │   │  │
│  │ │ B3: uint8_t temperature                         │   │  │
│  │ │ B4: uint8_t humidity                            │   │  │
│  │ │ B5-6: uint16_t mq9_ppm                          │   │  │
│  │ │ B7: uint8_t sensor_status                       │   │  │
│  │ └─────────────────────────────────────────────────┘   │  │
│  │ ┌─────────────────────────────────────────────────┐   │  │
│  │ │ MSG3: 模型状态 (ID=0x102, 每10次推理)          │   │  │
│  │ │ B0: uint8_t model_status (1=ok, 2=error)       │   │  │
│  │ │ B1: uint8_t inference_ms                        │   │  │
│  │ │ B2-3: uint16_t cycle_ms                         │   │  │
│  │ │ B4-5: uint16_t anomaly_count                    │   │  │
│  │ │ B6-7: uint16_t total_count                      │   │  │
│  │ └─────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                           ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 6️⃣  远程管理 (OTA + WiFi)                             │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ • 每30秒检查一次巴法云版本                              │  │
│  │ • 发现新版本 → 自动下载升级                            │  │
│  │ • WiFi连接失败 → 继续本地运行                          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 工作流程时序图

```
┌────────────────┐
│    SETUP()     │  系统初始化阶段
└────────┬────────┘
         │
         ├─→ 【Serial初始化】115200 bps
         │
         ├─→ 【LED初始化】GPIO2
         │
         ├─→ 【WiFi连接】"Mate 60" / "12345678"
         │   (失败也继续,仅影响OTA)
         │
         └─→ 【initializeAISystems()】
             ├─→ sensorHandler.init()
             │   ├─→ MPU6050.begin()
             │   ├─→ 设置加速度量程±8g
             │   ├─→ 设置陀螺仪量程±500°/s
             │   ├─→ 设置低通滤波5Hz
             │   └─→ DHT.begin()
             │
             ├─→ anomalyDetector.init()
             │   └─→ 加载模型(占位符模式)
             │
             └─→ canHandler.init()
                 ├─→ twai_driver_install()
                 ├─→ 设置GPIO8/9
                 ├─→ 配置500kbps波特率
                 └─→ twai_start()


┌─────────────────────────────────────────────────────────────┐
│                      LOOP() 主循环                          │
│                    (非阻塞设计)                             │
└──────────────┬──────────────────────────────────────────────┘
               │
        ┌──────┴──────┐
        │             │
        ↓             ↓
   【OTA检查】    【AI推理】
  (每30秒)       (每500ms)
        │             │
        │             ├─→ sensorHandler.readAllSensors()
        │             │   ├─→ MPU6050.getEvent()
        │             │   │   └─→ accel_x/y/z (m/s²)
        │             │   ├─→ DHT.readHumidity/Temperature()
        │             │   │   └─→ temperature (°C), humidity (%)
        │             │   └─→ analogRead(GPIO35)
        │             │       └─→ MQ9_ppm (ppm)
        │             │
        │             ├─→ 【规范化】normalizeSensorData()
        │             │   input_data[6] = {
        │             │     accel_x/8,
        │             │     accel_y/8,
        │             │     accel_z/8,
        │             │     (temp-25)/25,
        │             │     (humidity-50)/50,
        │             │     mq9_ppm/500
        │             │   }
        │             │
        │             ├─→ 【推理】anomalyDetector.runInference()
        │             │   safety_score = f(input_data[6])
        │             │   范围: 0.0 ~ 1.0
        │             │
        │             ├─→ 【判断异常】
        │             │   if (safety_score < 0.5) {
        │             │     anomaly_count++
        │             │     LED_ON
        │             │   } else {
        │             │     LED_OFF
        │             │   }
        │             │
        │             └─→ 【发送CAN】(每500ms)
        │                 ├─→ sendSafetyScore(0x100)
        │                 ├─→ sendSensorData(0x101)
        │                 └─→ sendModelStatus(0x102)
        │                     每10次发送一次
        │
        └─────────────→ delay(10ms)


每30秒触发一次:

【OTA版本检查】
  ├─→ HTTP POST to bemfa.com/api/ota/check
  ├─→ 解析JSON响应
  ├─→ if (云端版本 > 本地版本)
  │   └─→ updateBin()
  │       ├─→ 注册回调函数
  │       ├─→ httpUpdate.update()
  │       └─→ 升级完成后重启
  └─→ else
      └─→ 继续运行
```

---

## 4个模块详细说明

### 1️⃣ 传感器处理模块 (sensor_handler.h)

**作用:** 统一管理3个传感器的初始化和数据读取

**类: `SensorHandler`**

```cpp
class SensorHandler {
  // 成员变量
  Adafruit_MPU6050 mpu;      // I2C地址通常0x68
  DHT dht;                   // DHT11传感器(GPIO4)
  bool mpu_ok, dht_ok;       // 初始化状态标志

  // 关键方法
  bool init()                                    // 初始化所有传感器
  bool readAllSensors(SensorData_t &data)       // 读取所有传感器数据
  void normalizeSensorData(...)                 // 规范化到ML输入格式
  void printSensorData(const SensorData_t &)    // 调试输出
}
```

**数据结构: `SensorData_t`**
```cpp
typedef struct {
  float accel_x, accel_y, accel_z;   // MPU6050: -8~8 m/s²
  float temperature;                  // DHT11: -40~80°C
  float humidity;                     // DHT11: 0~100%
  float mq9_value;                    // MQ-9: 0~4095 (原始ADC值)
  float mq9_ppm;                      // MQ-9: 0~500+ ppm (浓度)
  uint32_t timestamp;                 // millis()
} SensorData_t;
```

**使用示例:**
```cpp
SensorHandler sensorHandler;

// 初始化(在setup中)
sensorHandler.init();

// 读取数据(在loop中)
SensorData_t data;
sensorHandler.readAllSensors(data);
Serial.print(data.accel_x);  // 加速度X轴

// 规范化成ML输入
float input[6];
sensorHandler.normalizeSensorData(data, input, 6);
// input[0~5]现在范围是 [-1, 1] 或 [0, 1]
```

**传感器接线:**
```
MPU6050 (I2C)
  VCC  → 3.3V
  GND  → GND
  SDA  → GPIO40 (I2C SDA)
  SCL  → GPIO41 (I2C SCL)

DHT11 (单线数字)
  VCC  → 3.3V
  GND  → GND
  DATA → GPIO4
        需要10k上拉电阻

MQ-9 (模拟)
  VCC  → 3.3V或5V
  GND  → GND
  A0   → GPIO35 (ADC1_CH7)
```

---

### 2️⃣ AI推理模块 (tf_lite_handler.h)

**作用:** 执行异常检测的神经网络推理

**类: `TFLiteAnomalyDetector`**

```cpp
class TFLiteAnomalyDetector {
  bool is_initialized;
  
  // 关键方法
  bool init()                                  // 加载模型
  float runInference(const float *input_data, int size)  // 执行推理
  bool isInitialized()                         // 检查状态
}
```

**当前工作模式: 占位符 (Placeholder Mode)**

系统已编译成功,但使用模拟的异常检测逻辑:

```cpp
float safety_score = 0.8f;  // 初始分数

// 规则1: 加速度异常降低分数
float accel_mag = sqrt(x² + y² + z²);
if (accel_mag > 0.8f) {
  safety_score -= (accel_mag - 0.8f) * 0.2f;
}

// 规则2: 温度/湿度异常降低分数
if (temp_norm > 0.5f || humidity_norm > 0.5f) {
  safety_score -= 0.1f;
}

// 最终: 确保在 [0, 1] 范围内
safety_score = clamp(safety_score, 0.0f, 1.0f);
```

**集成真实TFLite模型步骤:**

1. 准备你的TensorFlow Lite模型 `anomaly_detection_model.tflite`
2. 转换为C头文件:
   ```bash
   python3 convert_model.py anomaly_detection_model.tflite include/anomaly_model_data.h
   ```
3. 修改 `tf_lite_handler.h` 的 `init()` 和 `runInference()` 方法
4. 替换模拟逻辑为真实推理代码

---

### 3️⃣ CAN通信模块 (can_handler.h)

**作用:** 通过CAN总线发送AI推理结果

**类: `CANHandler`**

```cpp
class CANHandler {
  bool is_initialized;
  
  // 关键方法
  bool init()                          // 初始化CAN控制器
  bool sendSafetyScore(...)            // 发送安全系数
  bool sendSensorData(...)             // 发送传感器原始数据
  bool sendModelStatus(...)            // 发送模型状态统计
  bool sendError(uint8_t code, const char* msg)  // 发送错误信息
  bool receiveMessage(...)             // 接收CAN消息
}
```

**CAN消息定义:**

| 消息ID | 名称 | 用途 | 发送周期 |
|--------|------|------|---------|
| 0x100 | 安全系数 | 异常检测结果 | 每500ms |
| 0x101 | 传感器数据 | 原始传感器值 | 每500ms |
| 0x102 | 模型状态 | 推理性能统计 | 每5秒 |
| 0x7FF | 错误信息 | 系统异常告警 | 错误时 |

**消息0x100 (安全系数):**
```cpp
// 8字节帧
Byte0-3: float safety_score       // 0.0~1.0
Byte4-7: uint32_t timestamp       // millis()

// 使用示例
canHandler.sendSafetyScore(0.87f, millis());
```

**消息0x101 (传感器数据):**
```cpp
// 8字节帧
B0: int8_t accel_x        // -128~127 映射 -8~8 m/s²
B1: int8_t accel_y
B2: int8_t accel_z
B3: uint8_t temperature   // 0~100 映射 0~50°C
B4: uint8_t humidity      // 0~100%
B5-6: uint16_t mq9_ppm    // 0~500 ppm
B7: uint8_t sensor_status // 0x01=正常, 0x00=异常

// 使用示例
canHandler.sendSensorData(0.5, 0.2, -0.1, 25.0, 60.0, 120.0, 0x01);
```

**消息0x102 (模型状态):**
```cpp
// 8字节帧,每10次推理发送一次
B0: uint8_t model_status  // 1=正常运行
B1: uint8_t inference_ms  // 推理耗时 (毫秒)
B2-3: uint16_t cycle_ms   // 推理周期 (500ms)
B4-5: uint16_t anomaly_count   // 累计异常次数
B6-7: uint16_t total_count     // 累计推理次数

// 使用示例 (自动每10次推理调用)
if (total_count % 10 == 0) {
  canHandler.sendModelStatus(1, 15, 500, 3, 100);
}
```

**CAN接线 (使用TJA1050收发器):**
```
ESP32-S3    TJA1050    CAN总线
GPIO8(TX) → TXD
GPIO9(RX) → RXD        
3.3V ────→ VCC
GND ─────→ GND
          CANH ──→ CAN_H
          CANL ──→ CAN_L
```

---

### 4️⃣ 主程序框架 (main.cpp)

**流程:**

```cpp
setup()  {
  // 第1步: 启动Serial调试
  Serial.begin(115200);
  
  // 第2步: 初始化LED指示灯
  LED_INIT;
  
  // 第3步: 连接WiFi
  WiFi.begin(wifi_name, wifi_password);  // 最多等待10秒
  
  // 第4步: 初始化所有AI系统
  initializeAISystems();  // 调用初始化函数
}

loop() {
  // 定时器1: OTA版本检查 (每30秒)
  if (WiFi.isConnected && elapsed >= 30000ms) {
    getBemfaLatestVersion();
    if (新版本) updateBin();
  }
  
  // 定时器2: AI推理主循环 (每500ms)
  if (elapsed >= 500ms) {
    runAIInference();  // 这是核心处理函数
  }
  
  // 非阻塞延迟
  delay(10);
}
```

**runAIInference() - 核心推理函数:**

```cpp
void runAIInference() {
  // 【第1步】读取传感器
  SensorData_t data;
  bool sensor_ok = sensorHandler.readAllSensors(data);
  // data.accel_x, accel_y, accel_z, temperature, humidity, mq9_ppm都已填充
  
  // 【第2步】规范化数据
  float input_data[6];
  sensorHandler.normalizeSensorData(data, input_data, 6);
  // input_data现在: [-1~1, -1~1, -1~1, -1~1, -1~1, 0~1]
  
  // 【第3步】运行AI推理
  float safety_score = anomalyDetector.runInference(input_data, 6);
  // safety_score ∈ [0.0, 1.0]
  // 1.0 = 绝对安全, 0.0 = 绝对异常
  
  // 【第4步】判断是否异常
  if (safety_score < ANOMALY_THRESHOLD=0.5f) {
    // 异常状态
    anomaly_count++;              // 异常计数+1
    LED_ON;                       // 点亮红灯警报
    handleAnomalyDetection();     // 执行异常处理
  } else {
    // 正常状态
    LED_OFF;                      // 关闭指示灯
  }
  
  // 【第5步】通过CAN发送数据
  // 5.1 发送安全系数 (每次推理)
  canHandler.sendSafetyScore(safety_score, data.timestamp);
  
  // 5.2 发送传感器原始数据 (每次推理)
  canHandler.sendSensorData(
    data.accel_x, data.accel_y, data.accel_z,
    data.temperature, data.humidity, data.mq9_ppm,
    sensor_ok ? 0x01 : 0x00
  );
  
  // 5.3 发送模型状态 (每10次推理)
  if (total_inference_count % 10 == 0) {
    canHandler.sendModelStatus(
      1,                        // 状态: 正常
      (uint8_t)inference_ms,    // 推理耗时
      500,                      // 周期500ms
      anomaly_count,            // 异常计数
      total_inference_count     // 总推理次数
    );
  }
  
  // 【第6步】更新计数器
  total_inference_count++;
}
```

---

## 实际应用示例

### 场景: 工业设备监控

你的AI异常检测系统可以用在:
- **震动异常检测**: 机械设备异常震动 → 安全系数降低 → 预警
- **温度异常检测**: 设备过热 → 温度归一化值过高 → 预警
- **气体泄露检测**: 甲烷/酒精泄露 → MQ-9值升高 → 预警
- **综合异常**: 上述多项同时异常 → AI综合判断 → 预警

**系统工作流:**
```
物理世界 (设备/环境)
  ↓ 传感器采集
传感器数据 (原始值)
  ↓ 规范化 (-1~1)
AI模型输入
  ↓ 神经网络推理
安全系数 (0~1)
  ↓ 判断阈值 (0.5)
异常决策 (True/False)
  ↓ CAN发送
其他控制器 (接收指令)
  ↓ 执行动作
应急处理 (停机/报警/记录)
```

---

## 开发建议

### 👉 下一步: 集成真实TFLite模型

1. **准备模型**: 训练一个异常检测模型(如自编码器、LSTM等)
2. **导出模型**: TensorFlow → .tflite
3. **转换格式**: `.tflite` → C头文件
4. **修改推理代码**: 替换占位符为真实推理
5. **测试验证**: 在真实环境中测试性能

### 🔧 可定制的参数

在 `src/main.cpp` 中修改:

```cpp
// 推理周期 (默认500ms)
const unsigned long AI_INFERENCE_INTERVAL = 500;

// 异常阈值 (默认0.5, 范围0~1)
const float ANOMALY_THRESHOLD = 0.5f;

// OTA检查周期 (默认30秒)
const unsigned long OTA_CHECK_INTERVAL = 30000;
```

在 `include/sensor_handler.h` 中修改:

```cpp
// 规范化参数调整
// 加速度: -8~8 m/s² (可改为 -16~16)
normalized_input[0] = raw.accel_x / 8.0;

// 温度: 0~50°C (可改为 -40~80)
normalized_input[3] = (raw.temperature - 25.0) / 25.0;

// MQ-9: 0~500 ppm (需根据实际标定调整)
normalized_input[5] = (raw.mq9_ppm / 500.0);
```

---

## 性能指标

| 指标 | 值 | 说明 |
|------|-----|------|
| 推理延迟 | ~1ms | 模拟模式,实际TFLite可能10-50ms |
| 推理周期 | 500ms | 可调 |
| CAN波特率 | 500kbps | 标准工业级 |
| 内存占用 | <50KB | 除去TFLite模型 |
| 系统启动时间 | ~5s | 包括WiFi连接 |

---

## 故障排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 传感器数据全0 | I2C未连接 | 检查GPIO40/41和0x68地址 |
| DHT读取失败 | 单线问题 | 添加10k上拉,检查GPIO4 |
| CAN无输出 | GPIO8/9未连接 | 检查TJA1050接线 |
| 推理很慢 | 占位符模式正常 | 集成真实模型后会提速 |
| WiFi连接失败 | SSID/密码错误 | 检查大小写,不能有特殊字符 |

