# ESP32-S3 AI异常检测系统 (OTA + TensorFlow Lite + CAN)

## 系统架构

```
┌─────────────────────────────────────────────┐
│        ESP32-S3 Dev Kit M1                  │
├─────────────────────────────────────────────┤
│  传感器层                  AI推理层          │
├──────────────────┬──────────────────────────┤
│ • MPU6050(I2C)   │ • TensorFlow Lite       │
│ • DHT11(GPIO)    │ • 异常检测模型          │
│ • MQ-9(ADC)      │                         │
├─────────────────────────────────────────────┤
│  通信层                    OTA更新          │
├──────────────────┬──────────────────────────┤
│ • CAN (GPIO8/9)  │ • WiFi OTA              │
│ • TJA1050收发器  │ • 巴法云版本检查        │
└─────────────────────────────────────────────┘
```

## 硬件连接

### MPU6050 (加速度计)
```
VCC   → 3.3V
GND   → GND
SCL   → GPIO41 (I2C SCL)
SDA   → GPIO40 (I2C SDA)
```

### DHT11 (温湿度传感器)
```
VCC   → 3.3V
GND   → GND
DATA  → GPIO4
```

### MQ-9 (气体传感器)
```
VCC   → 3.3V / 5V
GND   → GND
A0    → GPIO35 (ADC1_CH7)
D0    → GPIO (可选)
```

### CAN总线 (TJA1050收发器)
```
ESP32-S3        TJA1050         CAN总线
GPIO8 (TX) ─→ TXD
GPIO9 (RX) ─→ RXD
3.3V ──────→ VCC
GND ───────→ GND
           CANH ──→ CANH
           CANL ──→ CANL
```

## 软件配置

### 1. 转换TensorFlow Lite模型

```bash
# 将你的 anomaly_detection_model.tflite 转换为C头文件
python3 convert_model.py anomaly_detection_model.tflite include/anomaly_model_data.h
```

### 2. 配置WiFi和OTA参数

编辑 `src/main.cpp` 中的配置部分：

```cpp
#define wifi_name "你的WiFi名称"
#define wifi_password "你的WiFi密码"

// 巴法云OTA配置
#define BEMFA_PRODUCT_KEY "你的产品Key"
#define BEMFA_DEVICE_NAME "esp32s3"
#define BEMFA_DEVICE_SECRET "你的设备密钥"

String upUrl = "你的固件URL";
```

### 3. 调整传感器参数

**传感器引脚配置** (在 `include/sensor_handler.h`):
```cpp
#define DHT_PIN 4          // DHT11数据引脚
#define DHT_TYPE DHT11     // DHT11型号
#define MQ9_PIN 35         // MQ-9模拟引脚
```

**传感器规范化范围** (在 `sensor_handler.h` 的 `normalizeSensorData()` 函数):
```cpp
// 调整这些值以匹配你的传感器范围
normalized_input[0] = raw.accel_x / 8.0;      // -8g to +8g
normalized_input[3] = (raw.temperature - 25.0) / 25.0;  // 0-50°C
normalized_input[4] = (raw.humidity - 50.0) / 50.0;     // 0-100%
normalized_input[5] = (raw.mq9_ppm / 500.0);  // 0-500 ppm
```

### 4. 异常检测阈值

编辑 `src/main.cpp` 中的阈值：

```cpp
const float ANOMALY_THRESHOLD = 0.5f;  // 安全系数阈值 (0-1)
// 低于此值表示异常
```

### 5. 推理周期

```cpp
const unsigned long AI_INFERENCE_INTERVAL = 500;  // 毫秒 (ms)
// 每500ms运行一次推理
```

## CAN消息格式

### 消息1: 安全系数 (ID: 0x100)
```
Byte 0-3: 安全系数 (float, 0.0-1.0)
Byte 4-7: 时间戳 (uint32_t, ms)
```

### 消息2: 传感器数据 (ID: 0x101)
```
Byte 0: 加速度X (-128~127 → -8~8 m/s²)
Byte 1: 加速度Y (-128~127 → -8~8 m/s²)
Byte 2: 加速度Z (-128~127 → -8~8 m/s²)
Byte 3: 温度 (0~100 → 0~50°C)
Byte 4: 湿度 (0~100 %)
Byte 5-6: MQ9浓度 (uint16_t, 0-500 ppm)
Byte 7: 传感器状态 (0x01=正常, 0x00=异常)
```

### 消息3: 模型状态 (ID: 0x102)
```
Byte 0: 模型状态 (1=正常, 2=错误)
Byte 1: 推理时间 (ms)
Byte 2-3: 处理周期 (ms)
Byte 4-5: 异常检测计数 (uint16_t)
Byte 6-7: 总处理计数 (uint16_t)
```

### 消息4: 错误信息 (ID: 0x7FF)
```
Byte 0: 错误代码
Byte 1-7: 错误消息 (ASCII字符)
```

## 编译和上传

```bash
# 编译
platformio run

# 上传到ESP32-S3 (指定COM口)
platformio run --target upload --upload-port COM12

# 查看串口日志
platformio device monitor --port COM12 --baud 115200
```

## 系统工作流程

1. **启动**
   - 初始化LED、Serial、WiFi
   - 连接WiFi网络
   - 初始化传感器、TFLite模型、CAN总线

2. **主循环**
   ```
   ┌─────────────────────┐
   │  OTA版本检查        │ (每30秒)
   │  ↓                  │
   │  读取传感器数据     │
   │  ↓                  │
   │  规范化数据         │ (每500ms)
   │  ↓                  │
   │  运行TFLite推理     │
   │  ↓                  │
   │  判断异常           │
   │  ↓                  │
   │  通过CAN发送结果    │
   └─────────────────────┘
   ```

3. **异常检测**
   - 如果安全系数 < 阈值 → LED亮 + 异常计数+1
   - 发送错误消息到CAN总线
   - 可调用 `handleAnomalyDetection()` 执行自定义逻辑

## 调试信息

系统会通过Serial输出详细的日志：

```
========== ESP32 AI异常检测系统启动 ==========
固件版本: 7
[WiFi] 正在连接...
[WiFi] 连接成功
IP: 192.168.1.100

[系统] 初始化AI边缘计算模块...
[系统] 初始化传感器...
[MPU6050] 初始化成功
[DHT11] 初始化成功
[系统] 初始化TensorFlow Lite模型...
[TFLite] 初始化模型...
[TFLite] 模型初始化成功
[系统] 初始化CAN总线...
[CAN] 初始化成功，波特率: 500000 bps
[系统] ✓ AI系统初始化完成

[传感器数据] AccelX:0.12m/s² | AccelY:-0.05m/s² | AccelZ:9.85m/s² | Temp:24.5°C | Hum:45% | MQ9:50ppm
[TFLite] 推理完成 (15.23ms) - 安全系数: 0.87
[AI] ✓ 正常，安全系数: 0.87
[CAN] 发送安全系数: 0.87
```

## 故障排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| MPU6050不初始化 | I2C地址不匹配 | 检查I2C连接，默认地址0x68 |
| DHT11读取失败 | GPIO连接松动 | 检查GPIO4连接，添加10k上拉电阻 |
| MQ-9数据异常 | 传感器未预热 | MQ-9需要预热24小时 |
| CAN通信失败 | 波特率不匹配 | 确认两端波特率都是500kbps |
| TFLite推理失败 | 模型文件错误 | 重新转换模型，检查输入尺寸 |
| WiFi连接失败 | WiFi参数错误 | 检查SSID、密码大小写 |

## 扩展功能

可以添加以下功能：
- SD卡日志记录
- MQTT远程监控
- 本地Web界面
- 多模型支持
- 在线模型更新
- 数据加密和验证

## 许可证

MIT License
