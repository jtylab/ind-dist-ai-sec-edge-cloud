#ifndef SENSOR_HANDLER_H
#define SENSOR_HANDLER_H

#include <Arduino.h>
#include <Adafruit_MPU6050.h>
#include <DHT.h>

// ===== 传感器配置 =====
#define DHT_PIN 4
#define DHT_TYPE DHT11
#define MQ9_PIN 35  // ADC1_CH7

// ===== 传感器数据结构 =====
typedef struct {
  float accel_x;      // MPU6050 加速度X轴
  float accel_y;      // MPU6050 加速度Y轴
  float accel_z;      // MPU6050 加速度Z轴
  float temperature;  // DHT11 温度
  float humidity;     // DHT11 湿度
  float mq9_value;    // MQ-9 模拟值 (0-4095)
  float mq9_ppm;      // MQ-9 浓度估计值 (ppm)
  uint32_t timestamp; // 时间戳
} SensorData_t;

class SensorHandler {
private:
  Adafruit_MPU6050 mpu;
  DHT dht;
  bool mpu_ok;
  bool dht_ok;
  
public:
  SensorHandler() : dht(DHT_PIN, DHT_TYPE), mpu_ok(false), dht_ok(false) {}
  
  // 初始化所有传感器
  bool init() {
    Serial.println("[传感器] 初始化中...");
    
    // MPU6050初始化
    if (!mpu.begin()) {
      Serial.println("[MPU6050] 初始化失败");
      mpu_ok = false;
    } else {
      mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
      mpu.setGyroRange(MPU6050_RANGE_500_DEG);
      mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
      Serial.println("[MPU6050] 初始化成功");
      mpu_ok = true;
    }
    
    // DHT11初始化
    dht.begin();
    dht_ok = true;
    Serial.println("[DHT11] 初始化成功");
    
    return mpu_ok && dht_ok;
  }
  
  // 读取所有传感器数据
  bool readAllSensors(SensorData_t &data) {
    data.timestamp = millis();
    bool success = true;
    
    // 读取MPU6050
    if (mpu_ok) {
      sensors_event_t accel, gyro, temp;
      mpu.getEvent(&accel, &gyro, &temp);
      
      data.accel_x = accel.acceleration.x;
      data.accel_y = accel.acceleration.y;
      data.accel_z = accel.acceleration.z;
    } else {
      data.accel_x = data.accel_y = data.accel_z = 0.0;
    }
    
    // 读取DHT11
    if (dht_ok) {
      data.humidity = dht.readHumidity();
      data.temperature = dht.readTemperature();
      
      // 检查读取是否成功
      if (isnan(data.humidity) || isnan(data.temperature)) {
        Serial.println("[DHT11] 读取失败");
        data.humidity = data.temperature = 0.0;
        success = false;
      }
    }
    
    // 读取MQ-9（模拟传感器）
    int raw_value = analogRead(MQ9_PIN);
    data.mq9_value = (float)raw_value;
    
    // MQ-9粗略的ppm计算（需要根据实际传感器标定调整）
    // Rs/R0 = (Vcc/Vo - 1) * R_load / R0
    // 假设标准环境R0=10k，负载电阻也是10k
    float voltage = (float)raw_value / 4095.0 * 3.3;
    float rs = 10000.0 * (3.3 - voltage) / voltage;
    float rs_r0 = rs / 10000.0;  // 假设R0 = 10k
    
    // 根据MQ-9特性曲线的近似公式: ppm = a * (RS/R0)^b
    // 这里使用简化公式，实际应根据标定曲线调整
    if (rs_r0 > 0) {
      data.mq9_ppm = 116.6 * pow(rs_r0, -2.769); // 近似公式
    } else {
      data.mq9_ppm = 0.0;
    }
    
    return success;
  }
  
  // 规范化传感器数据用于TFLite推理（调整范围到-1到1或其他范围）
  void normalizeSensorData(const SensorData_t &raw, float *normalized_input, int input_size) {
    if (input_size < 6) {
      Serial.println("[规范化] 输入大小不足");
      return;
    }
    
    // 规范化加速度（假设范围是 -8g 到 8g）
    normalized_input[0] = raw.accel_x / 8.0;
    normalized_input[1] = raw.accel_y / 8.0;
    normalized_input[2] = raw.accel_z / 8.0;
    
    // 规范化温度（假设范围 0-50°C）
    normalized_input[3] = (raw.temperature - 25.0) / 25.0;
    
    // 规范化湿度（0-100%）
    normalized_input[4] = (raw.humidity - 50.0) / 50.0;
    
    // 规范化MQ-9（0-500 ppm）
    normalized_input[5] = (raw.mq9_ppm / 500.0);
    
    // 截断到[-1, 1]范围
    for (int i = 0; i < 6; i++) {
      if (normalized_input[i] > 1.0f) normalized_input[i] = 1.0f;
      if (normalized_input[i] < -1.0f) normalized_input[i] = -1.0f;
    }
  }
  
  // 打印传感器数据（用于调试）
  void printSensorData(const SensorData_t &data) {
    Serial.print("[传感器数据] ");
    Serial.print("AccelX:");
    Serial.print(data.accel_x);
    Serial.print("m/s² | AccelY:");
    Serial.print(data.accel_y);
    Serial.print("m/s² | AccelZ:");
    Serial.print(data.accel_z);
    Serial.print("m/s² | ");
    Serial.print("Temp:");
    Serial.print(data.temperature);
    Serial.print("°C | Hum:");
    Serial.print(data.humidity);
    Serial.print("% | MQ9:");
    Serial.print(data.mq9_ppm);
    Serial.println("ppm");
  }
};

#endif // SENSOR_HANDLER_H
