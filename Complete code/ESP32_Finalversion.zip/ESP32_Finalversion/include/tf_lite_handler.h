#ifndef TF_LITE_HANDLER_H
#define TF_LITE_HANDLER_H

#include <Arduino.h>
#include <cmath>
#include "anomaly_model_data.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

// TFLite配置常量
const int kTensorArenaSize = 32 * 1024;  // 32KB的张量竞技场
const int kInputSize = 6;                // 输入特征数（3轴加速度 + 温度 + 湿度 + MQ9）
const int kOutputSize = 1;               // 输出为异常检测概率

class TFLiteAnomalyDetector {
private:
  uint8_t tensor_arena[kTensorArenaSize];
  tflite::MicroInterpreter* interpreter;
  const tflite::Model* model;
  bool is_initialized;
  
public:
  TFLiteAnomalyDetector() : interpreter(nullptr), model(nullptr), is_initialized(false) {}
  
  ~TFLiteAnomalyDetector() {}
  
  // 初始化TFLite模型
  bool init() {
    Serial.println("[TFLite] 初始化模型...");
    
    // 加载模型
    model = tflite::GetModel(anomaly_model_tflite);
    if (model == nullptr) {
      Serial.println("[TFLite] 模型加载失败");
      return false;
    }
    
    if (model->version() != TFLITE_SCHEMA_VERSION) {
      Serial.println("[TFLite] 模型schema版本不匹配");
      return false;
    }
    
    Serial.println("[TFLite] 模型加载成功");
    
    // 创建操作解析器 - 支持常用操作
    static tflite::MicroMutableOpResolver<16> resolver;
    
    // 添加必要的操作
    if (resolver.AddFullyConnected() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加FullyConnected操作");
      return false;
    }
    if (resolver.AddRelu() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Relu操作");
      return false;
    }
    if (resolver.AddRelu6() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Relu6操作");
      return false;
    }
    if (resolver.AddLogistic() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Logistic操作");
      return false;
    }
    if (resolver.AddQuantize() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Quantize操作");
      return false;
    }
    if (resolver.AddDequantize() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Dequantize操作");
      return false;
    }
    if (resolver.AddAdd() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Add操作");
      return false;
    }
    if (resolver.AddMul() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Mul操作");
      return false;
    }
    if (resolver.AddSoftmax() != kTfLiteOk) {
      Serial.println("[TFLite] 无法添加Softmax操作");
      return false;
    }
    
    Serial.println("[TFLite] 操作解析器创建成功");
    
    // 创建解释器
    static tflite::MicroInterpreter static_interpreter(
        model, resolver, tensor_arena, kTensorArenaSize, nullptr);
    interpreter = &static_interpreter;
    
    // 分配张量
    TfLiteStatus alloc_status = interpreter->AllocateTensors();
    if (alloc_status != kTfLiteOk) {
      Serial.println("[TFLite] 张量分配失败");
      return false;
    }
    
    Serial.println("[TFLite] 张量分配成功");
    Serial.print("[TFLite] 张量竞技场大小: ");
    Serial.print(kTensorArenaSize);
    Serial.println(" bytes");
    
    // 打印输入张量信息
    TfLiteTensor* input = interpreter->input(0);
    Serial.print("[TFLite] 输入张量形状: ");
    for (int i = 0; i < input->dims->size; i++) {
      Serial.print(input->dims->data[i]);
      Serial.print(" ");
    }
    Serial.println();
    
    is_initialized = true;
    Serial.println("[TFLite] 模型初始化成功!");
    
    return true;
  }
  
  // 运行推理
  float runInference(const float *input_data, int input_size) {
    if (!is_initialized) {
      Serial.println("[TFLite] 模型未初始化");
      return -1.0f;
    }
    
    if (interpreter == nullptr) {
      Serial.println("[TFLite] 解释器为空");
      return -1.0f;
    }
    
    if (input_size != kInputSize) {
      Serial.print("[TFLite] 输入大小不匹配: ");
      Serial.print(input_size);
      Serial.print(" != ");
      Serial.println(kInputSize);
      return -1.0f;
    }
    
    // 获取输入张量
    TfLiteTensor* input = interpreter->input(0);
    if (input == nullptr) {
      Serial.println("[TFLite] 无法获取输入张量");
      return -1.0f;
    }
    
    // 获取输入指针
    float* input_ptr = input->data.f;
    if (input_ptr == nullptr) {
      Serial.println("[TFLite] 无法获取输入指针");
      return -1.0f;
    }
    
    // 填充输入数据
    memcpy(input_ptr, input_data, input_size * sizeof(float));
    
    // 运行推理
    unsigned long start_time = micros();
    TfLiteStatus invoke_status = interpreter->Invoke();
    unsigned long elapsed = micros() - start_time;
    
    if (invoke_status != kTfLiteOk) {
      Serial.println("[TFLite] 推理执行失败");
      return -1.0f;
    }
    
    // 获取输出张量
    TfLiteTensor* output = interpreter->output(0);
    if (output == nullptr) {
      Serial.println("[TFLite] 无法获取输出张量");
      return -1.0f;
    }
    
    // 获取输出值
    float* output_ptr = output->data.f;
    if (output_ptr == nullptr) {
      Serial.println("[TFLite] 无法获取输出指针");
      return -1.0f;
    }
    
    float safety_score = output_ptr[0];
    
    // 确保输出在0-1范围
    if (safety_score > 1.0f) safety_score = 1.0f;
    if (safety_score < 0.0f) safety_score = 0.0f;
    
    Serial.print("[TFLite] 推理完成 (");
    Serial.print(elapsed / 1000.0);
    Serial.print("ms) - 安全系数: ");
    Serial.println(safety_score);
    
    return safety_score;
  }
  
  // 检查模型是否初始化
  bool isInitialized() const {
    return is_initialized;
  }
};

#endif // TF_LITE_HANDLER_H
