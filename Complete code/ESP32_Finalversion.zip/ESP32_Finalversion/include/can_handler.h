#ifndef CAN_HANDLER_H
#define CAN_HANDLER_H

#include <Arduino.h>
#include <driver/twai.h>
#include <string.h>

// ===== CAN配置 =====
#define CAN_RX_PIN 8      // ESP32-S3 GPIO8
#define CAN_TX_PIN 9      // ESP32-S3 GPIO9
#define CAN_BAUDRATE 500000  // 500kbps

// CAN消息ID定义
#define CAN_ID_SAFETY_SCORE 0x100      // 安全系数 (0x100)
#define CAN_ID_SENSOR_DATA 0x101       // 传感器数据 (0x101)
#define CAN_ID_MODEL_STATUS 0x102      // 模型状态 (0x102)
#define CAN_ID_ERROR 0x7FF             // 错误信息 (0x7FF)

// ===== CAN数据帧定义 =====

// 消息1: 安全系数 (8字节)
// Byte 0-3: 安全系数 (float)
// Byte 4-7: 时间戳 (uint32_t)
typedef struct {
  float safety_score;
  uint32_t timestamp;
} CAN_SafetyScore_t;

// 消息2: 传感器数据 (8字节)
// Byte 0: 加速度X (int8_t, -128~127 映射 -8~8 m/s²)
// Byte 1: 加速度Y (int8_t, -128~127 映射 -8~8 m/s²)
// Byte 2: 加速度Z (int8_t, -128~127 映射 -8~8 m/s²)
// Byte 3: 温度 (uint8_t, 0~100 映射 0~50°C)
// Byte 4: 湿度 (uint8_t, 0~100)
// Byte 5-6: MQ9浓度 (uint16_t, 0~500 ppm)
// Byte 7: 传感器状态标志
typedef struct {
  int8_t accel_x;
  int8_t accel_y;
  int8_t accel_z;
  uint8_t temperature;
  uint8_t humidity;
  uint16_t mq9_ppm;
  uint8_t sensor_status;
} CAN_SensorData_t;

// 消息3: 模型状态 (8字节)
// Byte 0: 模型状态 (0=未初始化, 1=正常, 2=错误)
// Byte 1: 推理时间(ms)
// Byte 2-3: 处理周期(ms)
// Byte 4-5: 异常检测计数
// Byte 6-7: 总处理计数
typedef struct {
  uint8_t model_status;    // 0=uninit, 1=ok, 2=error
  uint8_t inference_ms;
  uint16_t cycle_ms;
  uint16_t anomaly_count;
  uint16_t total_count;
} CAN_ModelStatus_t;

class CANHandler {
private:
  bool is_initialized;
  
public:
  CANHandler() : is_initialized(false) {}
  // 初始化CAN
  bool init() {
    Serial.println("[CAN] 初始化中...");
    
    // 配置TWAI驱动
    twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(
        (gpio_num_t)CAN_TX_PIN, 
        (gpio_num_t)CAN_RX_PIN,
        TWAI_MODE_NORMAL);
    
    // 配置总线定时器 - 使用标准ESP32宏定义
    twai_timing_config_t t_config = {
        .brp = 4,
        .tseg_1 = 15,
        .tseg_2 = 4,
        .sjw = 3,
        .triple_sampling = false
    };
    
    // 配置过滤器接收所有消息
    twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();
    
    // 安装驱动
    if (twai_driver_install(&g_config, &t_config, &f_config) != ESP_OK) {
      Serial.println("[CAN] 驱动安装失败");
      return false;
    }
    
    // 启动驱动
    if (twai_start() != ESP_OK) {
      Serial.println("[CAN] 驱动启动失败");
      twai_driver_uninstall();
      return false;
    }
    
    is_initialized = true;
    Serial.print("[CAN] 初始化成功，波特率: ");
    Serial.print(CAN_BAUDRATE);
    Serial.println(" bps");
    
    return true;
  }
  
  // 关闭CAN
  void deinit() {
    if (is_initialized) {
      twai_stop();
      twai_driver_uninstall();
      is_initialized = false;
    }
  }
  
  // 发送安全系数
  bool sendSafetyScore(float safety_score, uint32_t timestamp) {
    if (!is_initialized) {
      Serial.println("[CAN] 未初始化");
      return false;
    }
    
    twai_message_t message;
    message.identifier = CAN_ID_SAFETY_SCORE;
    message.data_length_code = 8;
    message.flags = 0;  // 标准帧
    
    // 将float转换为字节
    uint32_t *ptr = (uint32_t*)&safety_score;
    message.data[0] = (*ptr) & 0xFF;
    message.data[1] = (*ptr >> 8) & 0xFF;
    message.data[2] = (*ptr >> 16) & 0xFF;
    message.data[3] = (*ptr >> 24) & 0xFF;
    
    // 时间戳
    message.data[4] = timestamp & 0xFF;
    message.data[5] = (timestamp >> 8) & 0xFF;
    message.data[6] = (timestamp >> 16) & 0xFF;
    message.data[7] = (timestamp >> 24) & 0xFF;
    
    if (twai_transmit(&message, pdMS_TO_TICKS(10)) == ESP_OK) {
      Serial.print("[CAN] 发送安全系数: ");
      Serial.println(safety_score);
      return true;
    } else {
      Serial.println("[CAN] 发送安全系数失败");
      return false;
    }
  }
  
  // 发送传感器数据
  bool sendSensorData(float accel_x, float accel_y, float accel_z,
                      float temperature, float humidity, float mq9_ppm,
                      uint8_t sensor_status) {
    if (!is_initialized) {
      Serial.println("[CAN] 未初始化");
      return false;
    }
    
    twai_message_t message;
    message.identifier = CAN_ID_SENSOR_DATA;
    message.data_length_code = 8;
    message.flags = 0;
    
    message.data[0] = (int8_t)(accel_x / 8.0 * 127.0);
    message.data[1] = (int8_t)(accel_y / 8.0 * 127.0);
    message.data[2] = (int8_t)(accel_z / 8.0 * 127.0);
    message.data[3] = (uint8_t)((temperature / 50.0) * 100.0);
    message.data[4] = (uint8_t)(humidity);
    
    uint16_t mq9_val = (uint16_t)(mq9_ppm);
    message.data[5] = mq9_val & 0xFF;
    message.data[6] = (mq9_val >> 8) & 0xFF;
    message.data[7] = sensor_status;
    
    if (twai_transmit(&message, pdMS_TO_TICKS(10)) == ESP_OK) {
      return true;
    } else {
      Serial.println("[CAN] 发送传感器数据失败");
      return false;
    }
  }
  
  // 发送模型状态
  bool sendModelStatus(uint8_t model_status, uint8_t inference_ms,
                       uint16_t cycle_ms, uint16_t anomaly_count,
                       uint16_t total_count) {
    if (!is_initialized) {
      Serial.println("[CAN] 未初始化");
      return false;
    }
    
    twai_message_t message;
    message.identifier = CAN_ID_MODEL_STATUS;
    message.data_length_code = 8;
    message.flags = 0;
    
    message.data[0] = model_status;
    message.data[1] = inference_ms;
    
    message.data[2] = cycle_ms & 0xFF;
    message.data[3] = (cycle_ms >> 8) & 0xFF;
    
    message.data[4] = anomaly_count & 0xFF;
    message.data[5] = (anomaly_count >> 8) & 0xFF;
    
    message.data[6] = total_count & 0xFF;
    message.data[7] = (total_count >> 8) & 0xFF;
    
    if (twai_transmit(&message, pdMS_TO_TICKS(10)) == ESP_OK) {
      Serial.print("[CAN] 模型状态: Status=");
      Serial.print(model_status);
      Serial.print(" Inference=");
      Serial.print(inference_ms);
      Serial.println("ms");
      return true;
    } else {
      Serial.println("[CAN] 发送模型状态失败");
      return false;
    }
  }
  
  // 发送错误消息
  bool sendError(uint8_t error_code, const char *error_msg) {
    if (!is_initialized) {
      return false;
    }
    
    twai_message_t message;
    message.identifier = CAN_ID_ERROR;
    message.data_length_code = 8;
    message.flags = 0;
    
    message.data[0] = error_code;
    
    // 将错误消息复制到CAN帧（最多7字节）
    int msg_len = strlen(error_msg);
    if (msg_len > 7) msg_len = 7;
    memcpy(&message.data[1], error_msg, msg_len);
    
    // 填充剩余字节
    for (int i = msg_len + 1; i < 8; i++) {
      message.data[i] = 0;
    }
    
    if (twai_transmit(&message, pdMS_TO_TICKS(10)) == ESP_OK) {
      Serial.print("[CAN] 发送错误: ");
      Serial.println(error_msg);
      return true;
    } else {
      Serial.println("[CAN] 发送错误信息失败");
      return false;
    }
  }
  
  // 接收CAN消息
  bool receiveMessage(uint32_t &id, uint8_t *data, int &length) {
    if (!is_initialized) {
      return false;
    }
    
    twai_message_t message;
    esp_err_t err = twai_receive(&message, pdMS_TO_TICKS(0));
    
    if (err != ESP_OK) {
      return false;
    }
    
    id = message.identifier;
    length = message.data_length_code;
    memcpy(data, message.data, length);
    
    Serial.print("[CAN] 接收消息 ID=0x");
    Serial.print(id, HEX);
    Serial.print(" 长度=");
    Serial.println(length);
    
    return true;
  }
  // 检查CAN是否初始化
  bool isInitialized() {
    return is_initialized;
  }
};

#endif // CAN_HANDLER_H
