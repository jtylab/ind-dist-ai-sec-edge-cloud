# ESP32-TensorFlow-Lite-Sample
Sample project for deploying TensorFlow Lite models on the ESP32 using Platformio

Deploy to ESP32 using:
```platformio run -t upload --upload-port /dev/ttyUSB0```

Access Serial using:
```screen /dev/ttyUSB0 115200```
